// test/conservation.test.js — Milestone 2 acceptance: conservation at every
// step; integrated total flow = volume change; finite values; recruitment
// stays in [0,1].
//
// Per spec/TEST_PLAN.md §A.

const { ThreeCompartmentMechanics } = require('../src/mechanics.js');
const { makePatientParams, makeInitialState,
         makeBoundaryFlow, makeBoundaryPressure } = require('../src/contracts.js');
const { PRESETS } = require('../src/presets.js');

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); console.log('ok -', name); passed++; }
  catch (e) { console.error('FAIL -', name, ':', e.message); failed++; }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }

const mkParams = PRESETS.Baseline;

test('Initial state is finite', () => {
  const params = makePatientParams(mkParams());
  const state = makeInitialState(params);
  for (const c of state.compartments) {
    assert(Number.isFinite(c.volume), 'finite volume');
    assert(Number.isFinite(c.flow), 'finite flow');
    assert(Number.isFinite(c.alveolarPressure), 'finite alveolarP');
    assert(c.recruitment >= 0 && c.recruitment <= 1, 'r in [0,1]');
  }
  assert(state.airwayPressure === 0, 'baseline pressure');
  assert(state.totalVolume > 0, 'has initial volume');
});

test('Single step produces finite values', () => {
  const params = makePatientParams(mkParams());
  const state = makeInitialState(params);
  const boundary = makeBoundaryFlow({ flowLps: 0.4, fio2: 0.5 });
  const m = new ThreeCompartmentMechanics();
  const { state: ns, output } = m.step(params, state, boundary, 0.001);
  for (const c of ns.compartments) {
    assert(Number.isFinite(c.volume), 'finite V');
    assert(Number.isFinite(c.flow), 'finite Q');
    assert(Number.isFinite(c.alveolarPressure), 'finite P');
  }
  assert(Number.isFinite(ns.airwayPressure), 'finite Paw');
  assert(output.compartmentVolumes.length === 3, 'three compartments');
});

test('Flow conservation per step', () => {
  // Total flow = sum of compartment flows within tolerance.
  const params = makePatientParams(mkParams());
  const state = makeInitialState(params);
  const m = new ThreeCompartmentMechanics();
  const boundary = makeBoundaryFlow({ flowLps: 0.5, fio2: 0.5 });
  const { output } = m.step(params, state, boundary, 0.001);
  const sumComp = output.compartmentFlows.reduce((s, x) => s + x, 0);
  assert(Math.abs(sumComp - output.airwayFlow) < 1e-12,
    `airwayFlow ${output.airwayFlow} ≠ sum comp ${sumComp}`);
});

test('Volume change equals integrated flow', () => {
  // ΔV_total = Σ Q_i × dt within tolerance.
  const params = makePatientParams(PRESETS['Injury B']());
  const state = makeInitialState(params);
  const m = new ThreeCompartmentMechanics();
  const dt = 0.005;
  const boundary = makeBoundaryFlow({ flowLps: 0.4, fio2: 0.5 });
  const before = state.totalVolume;
  const { output, state: ns } = m.step(params, state, boundary, dt);
  const expectedDv = output.airwayFlow * dt;
  const actualDv = ns.totalVolume - before;
  assert(Math.abs(actualDv - expectedDv) < 1e-9,
    `ΔV ${actualDv} ≠ Q×dt ${expectedDv}`);
});

test('Pressure boundary type is honoured', () => {
  const params = makePatientParams(mkParams());
  const state = makeInitialState(params);
  const m = new ThreeCompartmentMechanics();
  const boundary = makeBoundaryPressure({ pressureCmH2O: 10, fio2: 0.5 });
  const { state: ns } = m.step(params, state, boundary, 0.001);
  assert(Math.abs(ns.airwayPressure - 10) < 1e-9,
    `Paw should be 10, got ${ns.airwayPressure}`);
});

test('Volume cannot go negative under passive recoil', () => {
  // Sustained Paw = AOP (zero driving pressure with relaxed compartments).
  const params = makePatientParams(PRESETS['Injury C']());
  const state = makeInitialState(params, { initialVolume: 0.0 });
  const m = new ThreeCompartmentMechanics();
  const boundary = makeBoundaryPressure({ pressureCmH2O: 0, fio2: 0.5 });
  const { state: ns } = m.step(params, state, boundary, 0.01);
  for (const c of ns.compartments) {
    assert(c.volume >= 0, `volume went negative: ${c.volume}`);
  }
});

test('Recruitment bounds are preserved', () => {
  const params = makePatientParams(PRESETS['Injury C']());
  const state = makeInitialState(params);
  // Force a state.recruitment[i] = 0.4 and verify the step doesn't change
  // it (frozen during Milestone 2 per the spec).
  state.compartments[1].recruitment = 0.4;
  const m = new ThreeCompartmentMechanics();
  const boundary = makeBoundaryFlow({ flowLps: 0.5, fio2: 0.5 });
  const { state: ns } = m.step(params, state, boundary, 0.001);
  assert(ns.compartments[1].recruitment === 0.4,
    `recruitment drifted: ${ns.compartments[1].recruitment}`);
});

test('Reject bad patient params', () => {
  // Tissue fractions not summing to 1.
  let threw = 0;
  try {
    makePatientParams({
      compartments: [{
        id: 'normal', fraction: 0.5, resistance: 1,
        capacity: 3.5, elasticScale: 1,
        perfusionFraction: 0.5, deadSpaceFraction: 0.3,
      }, {
        id: 'recruitable', fraction: 0.3, resistance: 1,
        capacity: 1.0, elasticScale: 1,
        perfusionFraction: 0.3, deadSpaceFraction: 0.3,
      }, {
        id: 'consolidated', fraction: 0.1, resistance: 1,
        capacity: 0.001, elasticScale: 1,
        perfusionFraction: 0.2, deadSpaceFraction: 0.3,
      }],
      centralAirwayResistance: 2.5,
      airwayOpeningPressure: 0,
    });
  } catch (_) { threw++; }
  assert(threw === 1, `expected throw, got ${threw}`);
});

console.log(`\nTests: passed=${passed} failed=${failed}`);
process.exit(failed === 0 ? 0 : 1);

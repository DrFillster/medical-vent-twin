# vent-review-package — for external LLM review

## What's in here

```
vent-review-package/
├── README-review.md            ← you are here
├── lung-reference/             ← NEW reference-backed revision (headline)
│   ├── README.md               (artifact entry point + scope)
│   ├── paper.html              (manuscript — new draft, not patched)
│   ├── index.html / app.js / style.css   (browser UI)
│   ├── lung_reference.py       (Python source of record — handoff package)
│   ├── test_lung_reference.py  (24 tests, Python)
│   ├── test_lung_reference.js  (24 tests, JS — byte-aligned)
│   ├── cross_check.py          (cross-language check at 1e-6)
│   ├── audit_reference.py      (Python audit)
│   ├── audit_lung_reference.js (JS audit mirror)
│   ├── harness.js              (Node CLI)
│   ├── lung.js                 (JS port — equations match Python)
│   ├── example_config.json
│   ├── package.json
│   ├── SHA256.json
│   └── results/
│       ├── benchmark.json      (Baseline / Injury A / Injury B / Injury C)
│       ├── audit.json          (Python)
│       ├── audit.js.json       (JS — matches Python at 1e-6)
│       ├── tests.txt           (Python test log)
│       ├── tests.js.txt        (JS test log)
│       └── example/scenario.json
├── _previous-draft/            ← preserved previous application
│   ├── index.html              (single-file original simulator)
│   ├── paper.html              (previous manuscript draft)
│   ├── README.md               (old README still uses "digital twin" framing)
│   ├── PUBLICATION_ASSESSMENT.md
│   ├── llms.txt, robots.txt, start.sh
└── _review-brief/              ← reviewer handoff brief (see below)
```

## What we want reviewed

- **`lung-reference/paper.html`** is the new manuscript draft.
- **`lung-reference/lung_reference.py`** is the source-of-record implementation.
- **`lung-reference/lung.js`** is the JavaScript port.
- **`lung-reference/cross_check.py`** is the cross-language verification harness.

The legacy single-file app and the previous manuscript draft are preserved
unmodified in `_previous-draft/` for diff context. They are NOT what we are
submitting; they are kept only because the reviewer brief instructed us to
"preserve the existing application in version control."

## What the artifact does

A mechanistic (not data-fit) three-compartment lung simulator:

- Quasi-static three-compartment elastic mechanics with one lumped airway
  resistance.
- Passive constant-flow VCV only; "dynamic parallel RC" and assisted
  ventilation are out of scope.
- Discrete relay-based PEEP-history recruitment (128 relays by default) —
  frozen during a breath.
- Steady shunt-only oxygen mixing (one ventilated alveolar PO₂; content-
  conserving mixing).
- Severinghaus saturation with P50 held fixed at 26.8 mmHg.
- Fixed-bicarbonate pH; no automatic Bohr/temp/COHb shift.
- A signed Recruitment-to-Inflation analogue (settling from 30 cmH₂O;
  conditioning step is a model-history input, not a clinical maneuver
  recommendation).
- A decremental P/V curve from 20 → 4 cmH₂O; the sampled compliance
  maximum is reported as such, never as a "best PEEP".
- Explicit failure states for AOP ≥ PEEP, invalid gas boundary, and
  capacity exhaust — returned visibly rather than coerced.

## What it is NOT

- **Not a clinical decision tool.** No diagnostically meaningful output.
  All outputs are model outputs, never patient measurements.
- **Not a digital twin.** The artifact is parameterised; it has no
  patient-specific fitting, learning, or calibration to clinical cohorts.
- **Not a cohort reproduction.** The four illustrative archetypes are
  parameter sets, not Berlin-grade reproductions. They do not attempt to
  reproduce the LUNG SAFE P/F IQR or the Chen R/I distribution.
- **Not bench-validated.** No ASL 5000 (or any test lung) comparison.
- **Not face-validated.** No expert panel review.
- **Not learner-validated.** No educational outcome study.

## How to verify the artifact

Open a terminal in `lung-reference/`:

```bash
# software verification (each language independently)
python3 -m unittest test_lung_reference.py
node test_lung_reference.js

# benchmarks + sensitivity sweeps
python3 lung_reference.py --out results
node harness.js --case "Injury C"
python3 audit_reference.py
node audit_lung_reference.js

# cross-language check (the contract for the JS port)
python3 cross_check.py
```

All four should pass cleanly. `cross_check.py` enforces absolute and
relative tolerance 1e-6 across Baseline + Injury A + Injury B + Injury C
plus power resolution, relay resolution, AOP sweep, Vt sweep, and FiO2
sweep.

## Where to start reading

1. `lung-reference/README.md` — artifact overview, scope, non-claims.
2. `lung-reference/paper.html` — the manuscript draft.
3. `lung-reference/lung_reference.py` — the source of record; 506
   lines, standard library only.
4. `lung-reference/cross_check.py` — the audit infrastructure.

If you only read three files, read those four (this list is too short
to fit).

## What is in `_review-brief/`

The handoff instructions that drove this revision. The brief enumerates
13 issues with the previous draft and a scope of work for the JS port.
It is provided as context so the reviewer can verify the issues were
addressed, but it is not part of the artifact.

## What we hope the reviewer flags

We'd value comments on:

1. **Equation correctness.** Conformance to Severinghaus 1979,
   alveolar gas equation, Chen-style R/I derivation. Verify the
   trapezoidal MP integration vs. the simplified Gattinoni linear form
   at the inputs used in `results/benchmark.json`.
2. **Test sufficiency.** Is the 24-test verification suite enough to
   demonstrate computational correctness, or is it overweight on edge
   cases and underweight on the bulk of input space?
3. **Manuscript claims.** Is the manuscript disciplined about the
   "mechanistic simulator, not a clinical decision tool" frame? Are
   the limitations (§4.5) sufficient, or should we enumerate more?
4. **Reproduction claims.** Confirm that nothing in `paper.html`
   asserts a clinical-cohort reproduction that the source code does
   not deliver. (We are explicit that it does not.)
5. **Cross-language check.** Is 1e-6 the right tolerance, or is the
   JS implementation passing only because the test inputs are
   inconvenient for FP error?

## What we DON'T want reviewed

- Whether the artifact is the right artifact to build.
- Whether browser-port simulators have educational value at all.
- Whether Python or JS is the better language for a research simulator.

Those questions are out of scope; the artifact exists, those decisions
were made before this revision. The reviewer's job is the artifact's
correctness, scope, and claims.

## Sandbox note

The artifact is fully self-contained. All inputs are exposed to the
user; no network calls; no data egress; no patient data was used;
no fitting was done. The only Internet access is `results/audit.json`
being read by JS at module load if a downstream caller chooses to
diff against it; nothing in the browser UI does this.
